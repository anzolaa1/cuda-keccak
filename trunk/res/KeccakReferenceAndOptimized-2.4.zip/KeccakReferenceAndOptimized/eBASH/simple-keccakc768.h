#define cKeccakB    1600
#define cKeccakR    832
#define cKeccakD    48
