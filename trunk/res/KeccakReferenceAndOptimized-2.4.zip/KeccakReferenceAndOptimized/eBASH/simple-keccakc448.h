#define cKeccakB    1600
#define cKeccakR    1152
#define cKeccakD    28
