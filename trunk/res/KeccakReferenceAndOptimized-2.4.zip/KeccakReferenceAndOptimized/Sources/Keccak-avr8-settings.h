#define	cKeccakR	1024
#define	cKeccakD	0
