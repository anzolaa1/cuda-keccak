#define cKeccakB    800
#define cKeccakR    544
#define cKeccakD    0
