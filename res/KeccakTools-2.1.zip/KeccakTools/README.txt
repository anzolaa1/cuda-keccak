KeccakTools is a set of C++ classes that can help analyze the Keccak sponge 
function family, designed by Guido Bertoni, Joan Daemen, Michaël Peeters and 
Gilles Van Assche. For more information, please refer to our website: 
http://keccak.noekeon.org/

KeccakTools version 2.1, June 2010.

RELEASE NOTES

When running Doxygen, if you encounter errors like this: "Pango-WARNING **: 
Error loading GPOS table 5503", please refer to http://simon.hoerder.de/node/18 
for a solution. On openSUSE, it consists in uninstalling the freefont package.
